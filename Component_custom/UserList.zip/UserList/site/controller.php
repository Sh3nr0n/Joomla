<?php
/**
 * Created by PhpStorm.
 * User: Lukas Lepez
 * Date: 26/07/2018
 * Time: 14:24
 */

//Cela permet de sécurisé le point d'entrée au niveau de la plateforme Joomla
defined('_JEXEC') or die('Restricted access');

class UserListController extends JControllerLegacy
{

}